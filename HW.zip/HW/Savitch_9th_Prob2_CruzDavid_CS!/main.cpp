/* 
 * File:   main.cpp
 * Author: David Cruz
 * Created on Jan,8,17 12:16 PM
 * Purpose:  Output CS is Cool Stuff!
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"****************************************************"<<endl;
    cout<<"    ccc                    ssss               !!"<<endl;
    cout<<"  c    c                 s     s              !!"<<endl;
    cout<<" c                        s                   !!"<<endl;
    cout<<"c                           s                 !!"<<endl;
    cout<<"c                             s               !!"<<endl;
    cout<<"c                               s             !!"<<endl;
    cout<<" c                              s             !!"<<endl;
    cout<<"  c    c                  s    s"<<endl;
    cout<<"    ccc                    ssss               OO     "<<endl;
    cout<<"****************************************************"<<endl;
    cout<<" Computer Science is Cool Stuff!!! "<<endl;
    


    //Exit
    return 0;
}

