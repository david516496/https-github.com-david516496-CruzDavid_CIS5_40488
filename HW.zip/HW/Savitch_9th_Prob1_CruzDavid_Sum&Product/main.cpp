/* 
 * File:   main.cpp
 * Author: David Cruz
 * Created on Jan,8,17 1:16 PM
 * Purpose:  Output Sum and Product
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    
   int frstInt;  // Declare variable named firstInt of the type int (integer)
   int scndInt; // Declare variable named secondInt of the type int
   int sum, product;
                  // Declare 2 variables of the type int to keep the results
 
   cout << "Enter first integer: ";   // Prompting message
   cin >> frstInt;                   // Read input from keyboard (cin) into firstInt
   cout << "Enter second integer: ";  // Prompting message
   cin >> scndInt;                  // Read input into secondInt
 
   // Math Operations
   sum        = frstInt + scndInt;
   product    = frstInt * scndInt;
   
 
   // Output
   cout << "The sum is: " << sum << endl;
   cout << "The product is: " << product << endl;
   

    
    
    //Exit
    return 0;
}

